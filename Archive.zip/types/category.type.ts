import { status_badge } from "./task.type";



export type category = {
    title: status_badge;
    id: number;
    icon: string
}